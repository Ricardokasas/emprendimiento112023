
<section class="page-section" id="lista_productos">
    <div class="container">
    
    <div class="row">
    <div class="col-md">
        
</div>
<div class="col-md">
<table class="table table-hover">
 <tr>
    <th>id</th>
    <th>Nombre</th>
    <th>Precio</th>
    <th>Descripción</th>
    <th>Tamaño</th>
    <th>Imagen</th>
 </tr>
                
<?
//if($_SESSION['usuario_valido']){

//}else{
//header('Location:index.php');
//}
include 'config/con.php';

$sql="SELECT id, nombre, precio_venta, imagen, descripcion, tamaño FROM tbl_productos order by id";
$reg=mysqli_query($con,$sql) or die("Error to list user");
while($r=mysqli_fetch_array($reg)){
    echo '<tr><td>'.$r["id"].'</td><td>'.$r["nombre"].'</td><td>'.$r["precio_venta"].'</td>
    <td>'.$r["descripcion"].'</td>
      <td>'.$r["tamaño"].'</td>
       <td><img src="imgproductos/'.$r["imagen"].'"></td></tr>';
  
    }
mysqli_close($con);
echo'</table>';
?>
</table>
</div>
</div>
</div>
</section>