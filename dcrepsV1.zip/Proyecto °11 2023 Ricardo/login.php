<section class="about_section layout_padding" id="login">
  
<form action="index.php" method="post">
  <div>
    <input type="text" placeholder="user Name "name="user"
      maxlength="40"/>

  </div>
  <div>
    <input type="password" placeholder="enter password" name="pwd"
      maxlength="15"/>

  </div>


  <div class="d-flex ">
    <button type="submit">
      SEND NOW
    </button>
  </div>
</form>
</section>