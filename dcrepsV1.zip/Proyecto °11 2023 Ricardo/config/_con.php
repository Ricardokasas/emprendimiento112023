<?
$host="";
$user="";
$pwd="";
$db="";
$con = mysqli_connect($host, $user, $pwd, $db) or
die("Problemas con la conexion");
?>