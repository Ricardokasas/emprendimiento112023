<?
session_start();
include 'head.php';
$id=$_REQUEST['id'];
$perfil=$_REQUEST['perfil'];
$id=trim($id);
?>
<div class="container">
    <div class="form-group">
    <?
    include 'conf/conexion.php';
    $sql='UPDATE tblusuarios set perfil="'.$perfil.'" WHERE id="'.$id.'"';
    $consulta=mysqli_query($con,$sql)
    or die("<div class='alert alert-succes'>Error</div>");
    echo "<div class='alert alert-succes'>Teneís un fallo, Manin.</div>";
    header('Location:lista_usuarios.php');
    ?>
    </div>
</div>