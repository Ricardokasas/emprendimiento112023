<?include 'head.php';?>
<div class="container-sm border">
<div class="form-group">

<?
$correo =$_POST['correo'];
$nombre =$_POST['nombre'];
$nro_documento=$_POST['nro_documento'];
$contrasena1 =$_POST['contrasena1'];
$contrasena2 =$_POST['contrasena2'];
$estado ="activo";
$perfil=0;
/* echo '<br>'.$correo;
echo '<br>'.$usuario;
echo '<br>'.$clave;
echo '<br>'.$rclave;*/
if ($contrasena1==$contrasena2){
include 'config/con.php';
$instruccion = "SELECT * FROM tbl_usuarios WHERE correo='$correo'";
$consulta = mysqli_query ($con, $instruccion) 
or die ("Fallo en la consulta correo");
//or die mysqli_errno($consulta);
// Mostrar resultados de la consulta
$nfilas = mysqli_num_rows ($consulta);
if ($nfilas == 0)
{
$salt = substr ($nombre, 0, 2);
$salt=strtoupper($salt);
$clave_crypt = crypt ($contrasena1, $salt);
$instruccion = "INSERT INTO tbl_usuarios (id, nombre, nro_documento, correo, contraseña, perfil, estado) 
values (null,'$nombre','$nro_documento','$correo','$clave_crypt','$perfil','$estado')";
$consulta = mysqli_query ($con, $instruccion) or die ("Fallo en la inserción");
mysqli_close ($con);
echo '<div class="alert alert-success alert-dismissible">';
echo '<button type="button" class="close" data-dismiss="alert">×</button>';
echo '<strong>Usuario: <br>'. $nombre. 'creado con éxito</strong> </div>';
}else{
echo '<div class="alert alert-danger alert-dismissible">';
echo '<button type="button" class="close" data-dismiss="alert">×</button>';
echo '<strong>Correo no válido</strong> </div>';
} }else{
echo '<div class="alert alert-danger alert-dismissible">';
echo '<button type="button" class="close" data-dismiss="alert">×</button>';
echo '<strong>Las claves no coinciden</strong> </div>';
}
echo "<meta http-equiv='refresh' content='2;url=index.php'/>";
?>
</div>
</div>