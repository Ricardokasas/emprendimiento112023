<?
include 'head.php';
include 'config/con.php';
$idproducto=$_REQUEST['id'];
$nombre="";
$costo_fabricacion="";
$precio_venta=0;
$maximo_stock="";
$minimo_stock="";
$beneficio_venta="";
$imagen="";
$descripcion="";
$tamaño="";
include 'config/con.php';
 $instruccion = "SELECT nombre,costo_fabricacion,precio_venta,beneficio_venta
                 FROM tbl_productos 
                 WHERE id='$idproducto'";
 $consulta = mysqli_query ( $con,$instruccion)
 or die ("Fallo en la consultar Usuario"); 

 while($reg=mysqli_fetch_array($consulta)){
       $nombre=$reg['nombre'];
       $costo_fabricacion=$reg['costo_fabricacion'];
       $precio_venta=$reg['precio_venta'];
   $maximo_stock=$reg['maximo_stock'];
   $minimo_stock=$reg['minimo_stock'];
   $beneficio_venta=$reg['beneficio_venta'];
   $imagen=$reg['venta'];
   $descripcion=$reg['descripcion'];
   $tamaño=$reg['tamaño'];
 }
 mysqli_close($con);
 if($perfil==0){
      $perfil="Usuario";
 }
 if($perfil==1){
      $perfil="Administrador";
 }
?>
<div class="page-section" id="editar_producto">
<div class="container">
<a href="lista_productos.php"><img src="images/house.png"></a>
<form method="post" action="salvar_producto.php">
 <div class="form-group">
 <label for="id">ID  </label>  
 <input type="text" 
         name="id"
        value=<? echo $idproducto?>
        class="form-control"
        readonly>
 </div>
 <div class="form-group">
 <label for="usuario">Usuario  </label>  
 <input type="text" 
         name="usuario"
        value=<? echo $usuario?> 
        class="form-control"
        readonly>
 </div>
   <div class="form-group">
 <label for="usuario">Usuario  </label>  
 <input type="text" 
         name="usuario"
        value=<? echo $usuario?> 
        class="form-control"
        readonly>
 </div>
   <div class="form-group">
 <label for="usuario">Usuario  </label>  
 <input type="text" 
         name="usuario"
        value=<? echo $usuario?> 
        class="form-control"
        readonly>
 </div>
   <div class="form-group">
 <label for="usuario">Usuario  </label>  
 <input type="text" 
         name="usuario"
        value=<? echo $usuario?> 
        class="form-control"
        readonly>
 </div>
   <div class="form-group">
 <label for="usuario">Usuario  </label>  
 <input type="text" 
         name="usuario"
        value=<? echo $usuario?> 
        class="form-control"
        readonly>
 </div>
   <div class="form-group">
 <label for="usuario">Usuario  </label>  
 <input type="text" 
         name="usuario"
        value=<? echo $usuario?> 
        class="form-control"
        readonly>
 </div>
   <div class="form-group">
 <label for="usuario">Usuario  </label>  
 <input type="text" 
         name="usuario"
        value=<? echo $usuario?> 
        class="form-control"
        readonly>
 </div>
   <div class="form-group">
 <label for="usuario">Usuario  </label>  
 <input type="text" 
         name="usuario"
        value=<? echo $usuario?> 
        class="form-control"
        readonly>
 </div>
 
<div class ="form-group">
      <button type="submit" class="btn btn-danger">Save</button>
</div>
</form>
 
 

</form>  

</div>
</div>