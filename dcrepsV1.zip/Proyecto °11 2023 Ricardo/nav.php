<nav class="navbar navbar-expand-lg custom_nav-container ">
            
  <a class="navbar-brand" href="index.php">
              Delicreps
            </a>
  <a class="navbar-brand" href="Manual.pdf">
   Manual
  </a>
  <a class="navbar-brand" >
             
            </a>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class=""> </span>
            </button>

            <div class="collapse navbar-collapse " id="navbarSupportedContent">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.php">Home:<?
 if(isset($_SESSION['usuario_valido'])){
echo 'bienvenido'.$_SESSION['usuario_valido'];}
 ?> <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="about.php"> Acerca</a>
                </li>
                
                <li class="nav-item">
                  <a class="nav-link" href="#lista_productos">Productos</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="lista.php">Pedir.</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="contact.php">Registrarse</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#login">Ingresar</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="lista_productos.php">Editar</a>
                </li>
              </ul>
              <div class="quote_btn-container">
                <form class="form-inline">
                  <button class="btn  my-2 my-sm-0 nav_search-btn" type="submit">
                    <i class="fa fa-search" aria-hidden="true"></i>
                  </button>
                </form>
                <a href="">
                  <i class="fa fa-user" aria-hidden="true"></i>
                </a>
              </div>
            </div>
          </nav>